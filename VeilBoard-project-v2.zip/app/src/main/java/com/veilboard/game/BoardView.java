package com.veilboard.game;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class BoardView extends View {
    interface Listener { void onBothThumbsHeld(); }
    private final Paint p = new Paint(3);
    private final Map<Character, PointF> letters = new LinkedHashMap<>();
    private final List<PointF> path = new ArrayList<>();
    private Listener listener;
    private Runnable stepSound;
    private float px, py;
    private boolean leftDown, rightDown, fired, moving;
    private long bothSince;

    BoardView(Context c) { super(c); setBackgroundColor(Color.rgb(31,21,13)); }
    void setListener(Listener l) { listener = l; }
    boolean isMoving() { return moving; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        LinearGradient wood = new LinearGradient(0,0,w,h, Color.rgb(165,111,54),Color.rgb(67,37,19), Shader.TileMode.CLAMP);
        p.setShader(wood); c.drawRoundRect(10,10,w-10,h-10,28,28,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);
        for(int i=0;i<18;i++){p.setColor(Color.argb(35+(i%3)*12,35,18,9));float y=18+(i*h/18f);c.drawPath(grain(w,y,i),p);}
        p.setStrokeWidth(7); p.setColor(Color.rgb(42,22,12)); c.drawRoundRect(20,20,w-20,h-20,22,22,p);
        p.setStrokeWidth(2);p.setColor(Color.rgb(203,150,78));c.drawRoundRect(29,29,w-29,h-29,18,18,p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create("serif",Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.rgb(45,25,15));
        p.setShadowLayer(1.5f,1,1,Color.rgb(210,154,78));setLayerType(LAYER_TYPE_SOFTWARE,p);
        p.setTextSize(h*.12f); c.drawText("V E I L   B O A R D",w/2,h*.14f,p);
        p.setTextSize(h*.085f); c.drawText("YES",w*.17f,h*.25f,p); c.drawText("NO",w*.83f,h*.25f,p);
        drawSun(c,w*.10f,h*.19f,h*.045f);drawMoon(c,w*.90f,h*.19f,h*.05f);
        letters.clear();
        String alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for(int i=0;i<alpha.length();i++) {
            int row=i<13?0:1, col=i%13; float x=w*.10f+col*(w*.80f/12f); float y=h*(row==0?.39f:.56f);
            letters.put(alpha.charAt(i),new PointF(x,y)); p.setTextSize(h*.095f); c.drawText(String.valueOf(alpha.charAt(i)),x,y,p);
        }
        String nums="1234567890"; p.setTextSize(h*.075f);
        for(int i=0;i<nums.length();i++) c.drawText(String.valueOf(nums.charAt(i)),w*.275f+i*w*.05f,h*.70f,p);
        p.setTextSize(h*.075f); c.drawText("G O O D B Y E",w/2,h*.82f,p);p.clearShadowLayer();
        drawThumb(c,w*.12f,h*.9f,leftDown,"HOLD"); drawThumb(c,w*.88f,h*.9f,rightDown,"HOLD");
        if(px==0){px=w/2;py=h*.68f;}
        drawPlanchette(c,w,h);
    }

    private Path grain(float w,float y,int seed){Path g=new Path();g.moveTo(20,y);for(int x=20;x<w-20;x+=55)g.quadTo(x+22,y+(float)Math.sin(seed*7+x)*5,x+55,y);return g;}
    private void drawSun(Canvas c,float x,float y,float r){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);for(int i=0;i<12;i++){double a=i*Math.PI/6;c.drawLine(x+(float)Math.cos(a)*r*1.3f,y+(float)Math.sin(a)*r*1.3f,x+(float)Math.cos(a)*r*1.8f,y+(float)Math.sin(a)*r*1.8f,p);}c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);}
    private void drawMoon(Canvas c,float x,float y,float r){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(x,y,r,p);c.drawArc(x-r*.45f,y-r,x+r*.9f,y+r,85,190,false,p);p.setStyle(Paint.Style.FILL);}
    private void drawPlanchette(Canvas c,float w,float h){
        float s=Math.min(w*.09f,h*.19f);Path q=new Path();q.moveTo(px,py-s*1.15f);q.cubicTo(px-s*1.15f,py-s*.75f,px-s*1.25f,py+s*.45f,px,py+s*1.2f);q.cubicTo(px+s*1.25f,py+s*.45f,px+s*1.15f,py-s*.75f,px,py-s*1.15f);q.close();
        p.setShadowLayer(10,5,7,Color.argb(180,0,0,0));p.setColor(Color.rgb(76,43,22));c.drawPath(q,p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(211,157,80));c.drawPath(q,p);p.setStyle(Paint.Style.FILL);p.setColor(Color.rgb(18,12,9));c.drawCircle(px,py-s*.18f,s*.30f,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(218,174,103));c.drawCircle(px,py-s*.18f,s*.30f,p);p.setStyle(Paint.Style.FILL);
    }

    private void drawThumb(Canvas c,float x,float y,boolean down,String text){
        p.setColor(down?Color.rgb(127,25,37):Color.argb(130,45,25,15));c.drawCircle(x,y,getWidth()*.075f,p);
        p.setTextSize(getWidth()*.027f);p.setColor(Color.rgb(232,205,145));c.drawText(text,x,y+8,p);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        leftDown=false;rightDown=false;
        for(int i=0;i<e.getPointerCount();i++){
            float x=e.getX(i),y=e.getY(i);
            if(y>getHeight()*.77f && x<getWidth()*.35f)leftDown=true;
            if(y>getHeight()*.77f && x>getWidth()*.65f)rightDown=true;
        }
        if(leftDown&&rightDown&&!moving){
            if(bothSince==0)bothSince=System.currentTimeMillis();
            if(!fired){ fired=true; postDelayed(()->{if(leftDown&&rightDown&&listener!=null)listener.onBothThumbsHeld();},550); }
        } else {bothSince=0;fired=false;}
        invalidate();return true;
    }

    void spell(String value,Runnable stepSound,Runnable done){
        this.stepSound=stepSound;
        path.clear();
        for(char ch:value.toUpperCase().toCharArray()){
            PointF pt=letters.get(ch); if(pt!=null)path.add(new PointF(pt.x,pt.y-getWidth()*.018f));
        }
        if(path.isEmpty()){done.run();return;} moving=true; animateAt(0,done);
    }

    private void animateAt(int i,Runnable done){
        if(i>=path.size()){moving=false;done.run();return;}
        if(stepSound!=null)stepSound.run();
        PointF target=path.get(i);ValueAnimator a=ValueAnimator.ofFloat(0,1);float sx=px,sy=py;
        a.setDuration(430);a.addUpdateListener(v->{float t=(float)v.getAnimatedValue();px=sx+(target.x-sx)*t;py=sy+(target.y-sy)*t;invalidate();});
        a.addListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator a){postDelayed(()->animateAt(i+1,done),120);}});a.start();
    }
}
