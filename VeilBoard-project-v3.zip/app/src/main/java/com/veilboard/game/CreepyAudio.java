package com.veilboard.game;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;

final class CreepyAudio {
    private final MediaPlayer ambience;
    private final SoundPool sounds;
    private final int scrapeId, revealId, whisperId;
    private long lastScrape;

    CreepyAudio(Context context) {
        ambience = MediaPlayer.create(context, R.raw.ambient_drone);
        if (ambience != null) { ambience.setLooping(true); ambience.setVolume(.22f, .22f); }
        AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
        sounds = new SoundPool.Builder().setMaxStreams(3).setAudioAttributes(attrs).build();
        scrapeId = sounds.load(context, R.raw.wood_scrape, 1);
        revealId = sounds.load(context, R.raw.reveal, 1);
        whisperId = sounds.load(context, R.raw.whisper, 1);
    }

    void startAmbience() { if (ambience != null && !ambience.isPlaying()) ambience.start(); }
    void pauseAmbience() { if (ambience != null && ambience.isPlaying()) ambience.pause(); }
    void reveal() { sounds.play(revealId, .55f, .55f, 1, 0, .82f); }
    void whisper() { sounds.play(whisperId, .45f, .45f, 1, 0, .9f); }
    void scrape() {
        long now=System.currentTimeMillis(); if(now-lastScrape<180)return; lastScrape=now;
        float rate=.72f+(now%37)/100f;sounds.play(scrapeId,.30f,.30f,0,0,rate);
    }
    void release() { if (ambience != null) ambience.release(); sounds.release(); }
}
