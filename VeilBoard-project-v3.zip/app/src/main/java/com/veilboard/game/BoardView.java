package com.veilboard.game;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class BoardView extends View {
    interface Listener { void onBothThumbsHeld(); }
    private final Paint p = new Paint(3);
    private final Bitmap boardArt;
    private final Bitmap planchetteArt;
    private final Map<Character, PointF> letters = new LinkedHashMap<>();
    private final List<PointF> path = new ArrayList<>();
    private Listener listener;
    private Runnable stepSound;
    private float px, py;
    private boolean leftDown, rightDown, fired, moving;
    private long bothSince;

    BoardView(Context c) {
        super(c); setBackgroundColor(Color.rgb(31,21,13));
        boardArt=BitmapFactory.decodeResource(getResources(),R.drawable.board_background);
        planchetteArt=BitmapFactory.decodeResource(getResources(),R.drawable.classic_planchette);
    }
    void setListener(Listener l) { listener = l; }
    boolean isMoving() { return moving; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        p.setStyle(Paint.Style.FILL);p.setAlpha(255);p.setFilterBitmap(true);
        c.drawBitmap(boardArt,null,new RectF(0,0,w,h),p);
        p.setColor(Color.argb(38,0,0,0));c.drawRoundRect(24,24,w-24,h-24,22,22,p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create("serif",Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.rgb(45,25,15));
        p.setShadowLayer(1.5f,1,1,Color.rgb(210,154,78));setLayerType(LAYER_TYPE_SOFTWARE,p);
        p.setTextSize(h*.12f); c.drawText("V E I L   B O A R D",w/2,h*.14f,p);
        p.setTextSize(h*.085f); c.drawText("YES",w*.17f,h*.25f,p); c.drawText("NO",w*.83f,h*.25f,p);
        letters.clear();
        String alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for(int i=0;i<alpha.length();i++) {
            int row=i<13?0:1, col=i%13; float x=w*.10f+col*(w*.80f/12f); float y=h*(row==0?.39f:.56f);
            letters.put(alpha.charAt(i),new PointF(x,y)); p.setTextSize(h*.095f); c.drawText(String.valueOf(alpha.charAt(i)),x,y,p);
        }
        String nums="1234567890"; p.setTextSize(h*.075f);
        for(int i=0;i<nums.length();i++) c.drawText(String.valueOf(nums.charAt(i)),w*.275f+i*w*.05f,h*.70f,p);
        p.setTextSize(h*.075f); c.drawText("G O O D B Y E",w/2,h*.82f,p);p.clearShadowLayer();
        drawThumb(c,w*.12f,h*.9f,leftDown,"HOLD"); drawThumb(c,w*.88f,h*.9f,rightDown,"HOLD");
        if(px==0){px=w/2;py=h*.68f;}
        drawPlanchette(c,w,h);
    }

    private void drawPlanchette(Canvas c,float w,float h){
        float dh=Math.min(h*.31f,w*.17f),dw=dh*planchetteArt.getWidth()/planchetteArt.getHeight();
        float top=py-dh*.39f;p.setAlpha(245);p.setFilterBitmap(true);
        c.drawBitmap(planchetteArt,null,new RectF(px-dw/2,top,px+dw/2,top+dh),p);p.setAlpha(255);
    }

    private void drawThumb(Canvas c,float x,float y,boolean down,String text){
        p.setColor(down?Color.rgb(127,25,37):Color.argb(130,45,25,15));c.drawCircle(x,y,getWidth()*.075f,p);
        p.setTextSize(getWidth()*.027f);p.setColor(Color.rgb(232,205,145));c.drawText(text,x,y+8,p);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        leftDown=false;rightDown=false;
        for(int i=0;i<e.getPointerCount();i++){
            float x=e.getX(i),y=e.getY(i);
            if(y>getHeight()*.77f && x<getWidth()*.35f)leftDown=true;
            if(y>getHeight()*.77f && x>getWidth()*.65f)rightDown=true;
        }
        if(leftDown&&rightDown&&!moving){
            if(bothSince==0)bothSince=System.currentTimeMillis();
            if(!fired){ fired=true; postDelayed(()->{if(leftDown&&rightDown&&listener!=null)listener.onBothThumbsHeld();},550); }
        } else {bothSince=0;fired=false;}
        invalidate();return true;
    }

    void spell(String value,Runnable stepSound,Runnable done){
        this.stepSound=stepSound;
        path.clear();
        for(char ch:value.toUpperCase().toCharArray()){
            PointF pt=letters.get(ch); if(pt!=null)path.add(new PointF(pt.x,pt.y-getWidth()*.018f));
        }
        if(path.isEmpty()){done.run();return;} moving=true; animateAt(0,done);
    }

    private void animateAt(int i,Runnable done){
        if(i>=path.size()){moving=false;done.run();return;}
        if(stepSound!=null)stepSound.run();
        PointF target=path.get(i);ValueAnimator a=ValueAnimator.ofFloat(0,1);float sx=px,sy=py;
        a.setDuration(430);a.addUpdateListener(v->{float t=(float)v.getAnimatedValue();px=sx+(target.x-sx)*t;py=sy+(target.y-sy)*t;invalidate();});
        a.addListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator a){postDelayed(()->animateAt(i+1,done),120);}});a.start();
    }
}
