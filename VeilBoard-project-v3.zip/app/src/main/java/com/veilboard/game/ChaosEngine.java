package com.veilboard.game;

import android.content.Context;
import android.os.BatteryManager;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class ChaosEngine {
    static final class Reply {
        final String entity, message;
        Reply(String entity, String message) { this.entity = entity; this.message = message; }
    }

    private final SecureRandom random = new SecureRandom();
    private final Context context;
    private final String nickname;
    private final boolean personal;
    private String entity;

    private static final String[] FIRST = {"Morrow", "The Pale", "Vesper", "Ash", "Hollow", "Sable", "Ninth", "Old"};
    private static final String[] LAST = {"Witness", "Mariner", "Guest", "Keeper", "Voice", "Pilgrim", "Bell", "One"};
    private static final String[] YES = {"YES", "IT IS ALREADY MOVING", "YOU KNOW THE ANSWER", "NOT YET", "ASK AGAIN", "THE DOOR IS OPEN"};
    private static final String[] WHO = {"A NAME FORGOTTEN", "SOMEONE NEAR", "THE ONE WHO WAITED", "A FRIEND OF THE DARK", "NO ONE YOU REMEMBER"};
    private static final String[] WHY = {"BECAUSE YOU CALLED", "BECAUSE SILENCE GETS LONELY", "TO SHOW WHAT YOU HIDE", "THE REASON COMES LATER", "YOU BROUGHT THE QUESTION"};
    private static final String[] OMENS = {"LOOK BEHIND THE HABIT YOU CANNOT BREAK", "THE SMALL CHOICE RETURNS", "SOMETHING LOST IS STILL CLOSE", "YOU PRETEND NOT TO NOTICE THE PATTERN", "A QUIET CHANGE HAS ALREADY BEGUN"};

    ChaosEngine(Context context, String nickname, boolean personal) {
        this.context = context;
        this.nickname = nickname == null ? "" : nickname.trim();
        this.personal = personal;
        rerollEntity();
    }

    String entity() { return entity; }
    void rerollEntity() { entity = pick(FIRST) + " " + pick(LAST); }

    Reply answer(String question) {
        String q = question.toLowerCase(Locale.ROOT);
        String answer;
        int branch = random.nextInt(100);
        if (q.matches(".*\\b(who|name)\\b.*")) answer = pick(WHO);
        else if (q.matches(".*\\bwhy\\b.*")) answer = pick(WHY);
        else if (q.matches(".*\\b(will|can|do|is|are|should|did)\\b.*") && branch < 65) answer = pick(YES);
        else answer = pick(OMENS);

        if (personal && random.nextInt(100) < 48) answer = personalFragment() + ". " + answer;
        if (random.nextInt(100) < 12) answer = "GOODBYE";
        return new Reply(entity, answer);
    }

    private String personalFragment() {
        int hour = Integer.parseInt(new SimpleDateFormat("H", Locale.ROOT).format(new Date()));
        BatteryManager bm = (BatteryManager) context.getSystemService(Context.BATTERY_SERVICE);
        int battery = bm == null ? -1 : bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);
        String name = nickname.isEmpty() ? "YOU" : nickname.toUpperCase(Locale.ROOT);
        String[] lines = {
            name + ", YOU NOTICE MORE THAN YOU ADMIT",
            "YOU HAVE BEEN THINKING ABOUT A CHANGE",
            "SOMEONE EXPECTS AN ANSWER FROM YOU",
            hour >= 22 || hour < 5 ? "YOU SHOULD NOT HAVE ASKED THIS LATE" : "YOU SAVED THE HARD QUESTION FOR NOW",
            battery >= 0 && battery < 25 ? "EVEN YOUR BATTERY IS RUNNING OUT" : "YOU CAME HERE EXPECTING A SIGN",
            "THE DETAIL YOU KEEP REPLAYING MATTERS"
        };
        return pick(lines);
    }

    private String pick(String[] values) { return values[random.nextInt(values.length)]; }
}
