# Veil Board

A privacy-conscious Android séance game prototype. Hold one thumb in each lower corner, ask a question aloud, and watch a randomized entity move the planchette across its reply while the exchange is recorded below.

## Features

- Two-thumb hold gesture (550 ms) to activate listening
- Android speech recognition with offline preference
- Random entity names and weighted, keyword-sensitive “chaos” replies
- Animated letter-by-letter planchette
- Scrollable session transcript
- Optional on-device Barnum-style personalization using only nickname, time, and battery level
- No network permission, analytics, ads, contacts, location, or data upload

## Run

Open the project in Android Studio, let it install the requested Android SDK/Gradle components, and run on an Android 8.0+ physical device. Grant microphone access when prompted. Speech recognition availability depends on the recognition service installed on the device.

Alternatively, push the project to GitHub. The included **Build test APK** workflow compiles a debug APK and stores it as the `VeilBoard-debug-apk` Actions artifact.

## Product note

The experience is fictional entertainment. If expanded for release, keep personalization opt-in, add an easy reset/privacy screen, and avoid claims that the app contacts real entities.
