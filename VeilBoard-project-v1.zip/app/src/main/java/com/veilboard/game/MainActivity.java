package com.veilboard.game;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.*;
import android.view.Gravity;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity implements RecognitionListener {
    private BoardView board;
    private TextView status, transcript;
    private SpeechRecognizer recognizer;
    private ChaosEngine chaos;
    private boolean listening;

    @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();setupProfile();}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(16,11,8));
        status=new TextView(this);status.setText("PLACE BOTH THUMBS TO SPEAK");status.setTextColor(Color.rgb(216,183,117));status.setGravity(Gravity.CENTER);status.setPadding(8,18,8,18);
        board=new BoardView(this);root.addView(status,new LinearLayout.LayoutParams(-1,-2));root.addView(board,new LinearLayout.LayoutParams(-1,0,7));
        ScrollView scroll=new ScrollView(this);transcript=new TextView(this);transcript.setTextColor(Color.rgb(222,204,166));transcript.setTextSize(15);transcript.setPadding(22,14,22,24);transcript.setText("SESSION TRANSCRIPT\n");scroll.addView(transcript);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,3));setContentView(root);
        board.setListener(this::beginListening);
    }

    private void setupProfile(){
        android.content.SharedPreferences prefs=getSharedPreferences("veil",MODE_PRIVATE);
        if(prefs.contains("setup")){ startSession(prefs.getString("nickname",""),prefs.getBoolean("personal",false));return; }
        EditText name=new EditText(this);name.setHint("Nickname (optional)");
        new AlertDialog.Builder(this).setTitle("Before the séance")
            .setMessage("Optionally let the game use your nickname, current time, and battery level for eerie lines. Nothing leaves this device. You can decline.")
            .setView(name).setPositiveButton("Allow local personalization",(d,w)->{prefs.edit().putBoolean("setup",true).putBoolean("personal",true).putString("nickname",name.getText().toString()).apply();startSession(name.getText().toString(),true);})
            .setNegativeButton("No personalization",(d,w)->{prefs.edit().putBoolean("setup",true).putBoolean("personal",false).apply();startSession("",false);}).setCancelable(false).show();
    }

    private void startSession(String name,boolean personal){chaos=new ChaosEngine(this,name,personal);append("— "+chaos.entity()+" is present —");}

    private void beginListening(){
        if(board.isMoving()||listening)return;
        if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},7);return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("VOICE RECOGNITION IS UNAVAILABLE");return;}
        if(recognizer==null){recognizer=SpeechRecognizer.createSpeechRecognizer(this);recognizer.setRecognitionListener(this);}
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,false);i.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);
        listening=true;status.setText("LISTENING… RELEASE YOUR THUMBS");recognizer.startListening(i);
    }

    private void respond(String words){
        append("YOU: "+words);ChaosEngine.Reply r=chaos.answer(words);status.setText(r.entity().toUpperCase()+" IS MOVING…");
        board.spell(r.message,()->{append(r.entity().toUpperCase()+": "+r.message);status.setText("PLACE BOTH THUMBS TO SPEAK");});
    }

    private void append(String line){transcript.append("\n"+line+"\n");}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==7&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)beginListening();else status.setText("MICROPHONE PERMISSION IS NEEDED TO PLAY");}
    @Override public void onResults(Bundle b){listening=false;ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(x!=null&&!x.isEmpty())respond(x.get(0));else status.setText("THE BOARD HEARD NOTHING");}
    @Override public void onError(int e){listening=false;status.setText(e==SpeechRecognizer.ERROR_NO_MATCH?"THE BOARD HEARD NOTHING":"THE CONNECTION WENT QUIET — TRY AGAIN");}
    @Override public void onReadyForSpeech(Bundle b){} @Override public void onBeginningOfSpeech(){} @Override public void onRmsChanged(float r){} @Override public void onBufferReceived(byte[] b){} @Override public void onEndOfSpeech(){status.setText("THE BOARD IS THINKING…");} @Override public void onPartialResults(Bundle b){} @Override public void onEvent(int t,Bundle b){}
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.destroy();super.onDestroy();}
}
