package com.veilboard.game;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class BoardView extends View {
    interface Listener { void onBothThumbsHeld(); }
    private final Paint p = new Paint(3);
    private final Map<Character, PointF> letters = new LinkedHashMap<>();
    private final List<PointF> path = new ArrayList<>();
    private Listener listener;
    private float px, py;
    private boolean leftDown, rightDown, fired, moving;
    private long bothSince;

    BoardView(Context c) { super(c); setBackgroundColor(Color.rgb(31,21,13)); }
    void setListener(Listener l) { listener = l; }
    boolean isMoving() { return moving; }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float w=getWidth(), h=getHeight();
        LinearGradient wood = new LinearGradient(0,0,w,h, Color.rgb(181,132,72),Color.rgb(88,52,27), Shader.TileMode.CLAMP);
        p.setShader(wood); c.drawRoundRect(10,10,w-10,h-10,28,28,p); p.setShader(null);
        p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(5); p.setColor(Color.rgb(45,27,17)); c.drawRoundRect(20,20,w-20,h-20,22,22,p);
        p.setStyle(Paint.Style.FILL); p.setTypeface(Typeface.create("serif",Typeface.BOLD)); p.setTextAlign(Paint.Align.CENTER); p.setColor(Color.rgb(45,25,15));
        p.setTextSize(w*.08f); c.drawText("VEIL BOARD",w/2,h*.11f,p);
        p.setTextSize(w*.055f); c.drawText("YES",w*.19f,h*.20f,p); c.drawText("NO",w*.81f,h*.20f,p);
        letters.clear();
        String alpha="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for(int i=0;i<alpha.length();i++) {
            int row=i<13?0:1, col=i%13; float x=w*.09f+col*(w*.82f/12f); float y=h*(row==0?.34f:.49f);
            letters.put(alpha.charAt(i),new PointF(x,y)); p.setTextSize(w*.047f); c.drawText(String.valueOf(alpha.charAt(i)),x,y,p);
        }
        String nums="1234567890"; p.setTextSize(w*.045f);
        for(int i=0;i<nums.length();i++) c.drawText(String.valueOf(nums.charAt(i)),w*.16f+i*w*.075f,h*.63f,p);
        p.setTextSize(w*.052f); c.drawText("GOODBYE",w/2,h*.74f,p);
        drawThumb(c,w*.12f,h*.9f,leftDown,"HOLD"); drawThumb(c,w*.88f,h*.9f,rightDown,"HOLD");
        if(px==0){px=w/2;py=h*.68f;}
        p.setColor(Color.argb(205,42,25,17)); c.drawOval(px-w*.10f,py-w*.07f,px+w*.10f,py+w*.07f,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(222,183,106));c.drawCircle(px,py,w*.033f,p);p.setStyle(Paint.Style.FILL);
    }

    private void drawThumb(Canvas c,float x,float y,boolean down,String text){
        p.setColor(down?Color.rgb(127,25,37):Color.argb(130,45,25,15));c.drawCircle(x,y,getWidth()*.075f,p);
        p.setTextSize(getWidth()*.027f);p.setColor(Color.rgb(232,205,145));c.drawText(text,x,y+8,p);
    }

    @Override public boolean onTouchEvent(MotionEvent e){
        leftDown=false;rightDown=false;
        for(int i=0;i<e.getPointerCount();i++){
            float x=e.getX(i),y=e.getY(i);
            if(y>getHeight()*.77f && x<getWidth()*.35f)leftDown=true;
            if(y>getHeight()*.77f && x>getWidth()*.65f)rightDown=true;
        }
        if(leftDown&&rightDown&&!moving){
            if(bothSince==0)bothSince=System.currentTimeMillis();
            if(!fired){ fired=true; postDelayed(()->{if(leftDown&&rightDown&&listener!=null)listener.onBothThumbsHeld();},550); }
        } else {bothSince=0;fired=false;}
        invalidate();return true;
    }

    void spell(String value,Runnable done){
        path.clear();
        for(char ch:value.toUpperCase().toCharArray()){
            PointF pt=letters.get(ch); if(pt!=null)path.add(new PointF(pt.x,pt.y-getWidth()*.018f));
        }
        if(path.isEmpty()){done.run();return;} moving=true; animateAt(0,done);
    }

    private void animateAt(int i,Runnable done){
        if(i>=path.size()){moving=false;done.run();return;}
        PointF target=path.get(i);ValueAnimator a=ValueAnimator.ofFloat(0,1);float sx=px,sy=py;
        a.setDuration(430);a.addUpdateListener(v->{float t=(float)v.getAnimatedValue();px=sx+(target.x-sx)*t;py=sy+(target.y-sy)*t;invalidate();});
        a.addListener(new AnimatorListenerAdapter(){@Override public void onAnimationEnd(Animator a){postDelayed(()->animateAt(i+1,done),120);}});a.start();
    }
}
